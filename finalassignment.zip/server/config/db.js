/*--
Author: Christine Kweri
Student ID : 300957096
Date: 10-11-2020
FileName : db.js

Where to connect from
*/

module.exports =
{
   //"URI": "mongodb://localhost/contact"
   "URI": "mongodb+srv://christine:uueAlVIKiJ44sLKJ@mongodbserver.u22hw.mongodb.net/contact?retryWrites=true&w=majority"
}